<?php
//include("config.php");
//session_start();

?>

<?php
//$sid = $_SESSION['id'];

$email = "slmnakber@gmail.com";
  

  require('class.phpmailer.php');
$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 0;
$mail->SMTPAuth = TRUE;
$mail->SMTPSecure = "ssl";
$mail->Port     = 465;  
$mail->Username = "akhan44431@gmail.com";
$mail->Password = "SAFIYAKHAN1";
$mail->Host     = "smtp.gmail.com";
$mail->Mailer   = "smtp";
$mail->SetFrom("akhan44431@gmail.com", "www.shopping.com");
$mail->AddReplyTo($email,"");
$mail->AddAddress($email);
$mail->Subject = "www.shopping.com";
$mail->WordWrap   = 80;
$content = "
<div style='border:1px solid #ddd; height:400px; width:800px; border-top: 200px solid #eb122e;'>





</div>
";   $mail->MsgHTML($content);
$mail->IsHTML(true);
if(!$mail->Send()) 
echo "403";
else 

 echo "200";













?> 
